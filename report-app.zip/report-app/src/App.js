// import React, { useState } from 'react';
// import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
// import AuthForm from './components/AuthForm';
// import Dashboard from './components/Dashboard';
// import './styles.css';

// function App() {
//   const [user, setUser] = useState(null);

//   // Function to handle login success and set user data
//   const handleLoginSuccess = (userData) => {
//     setUser(userData);
//   };

//   return (
//     <Router>
//       <Routes>
//         <Route
//           path="/"
//           element={user ? <Navigate to="/dashboard" /> : <AuthForm onLoginSuccess={handleLoginSuccess} />}
//         />
//         <Route
//           path="/dashboard"
//           element={user ? <Dashboard user={user} /> : <Navigate to="/" />}
//         />
//         {/* Add routes for report scanner and history here */}
//       </Routes>
//     </Router>
//   );
// }

// export default App;

// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AuthForm from './components/AuthForm';
import Dashboard from './components/Dashboard';
import ReportScanner from './components/ReportScanner'; // Import ReportScanner
import './styles.css';

function App() {
  const [user, setUser] = useState(null);

  const handleLoginSuccess = (userData) => {
    setUser(userData);
  };

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={user ? <Navigate to="/dashboard" /> : <AuthForm onLoginSuccess={handleLoginSuccess} />}
        />
        <Route
          path="/dashboard"
          element={user ? <Dashboard user={user} /> : <Navigate to="/" />}
        />
        <Route
          path="/report-scanner"
          element={user ? <ReportScanner /> : <Navigate to="/" />} // Add route for ReportScanner
        />
        {/* Add routes for other components like history here */}
      </Routes>
    </Router>
  );
}

export default App;
