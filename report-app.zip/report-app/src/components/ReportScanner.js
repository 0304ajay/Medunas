// src/components/ReportScanner.js
import React, { useState } from 'react';
import axios from 'axios';
import './ReportScanner.css';

function ReportScanner() {
  const [file, setFile] = useState(null);
  const [processingResult, setProcessingResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      alert('Please select a file first');
      return;
    }

    setLoading(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      // Replace 'your-api-url' with your actual API Gateway or AWS Lambda endpoint
      const response = await axios.post(' https://iduu2pe1i4.execute-api.ap-southeast-2.amazonaws.com/prod/process-report', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      setProcessingResult(response.data); // Assume the response has the processed text
      setFile(null);
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Failed to process file');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="report-scanner">
      <div className="scanner-header">
        <h2>Report Scanner</h2>
        <p>Upload a PDF or image report to scan and analyze.</p>
      </div>
      
      <div className="file-upload-section">
        {/* Label for file input */}
        <label className="custom-file-upload">
          <input 
            type="file" 
            accept="application/pdf,image/*" 
            onChange={handleFileChange} 
          />
          {file ? file.name : 'Choose a file'}
        </label>
        <button onClick={handleUpload} disabled={loading}>
          {loading ? 'Processing...' : 'Upload and Scan'}
        </button>
      </div>

      {processingResult && (
        <div className="result-section">
          <h3>Processing Result:</h3>
          <p>{processingResult.text}</p>
        </div>
      )}
    </div>
  );
}

export default ReportScanner;
